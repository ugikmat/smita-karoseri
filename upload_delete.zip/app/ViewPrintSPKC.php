<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ViewPrintSPKC extends Model
{
    //
}
