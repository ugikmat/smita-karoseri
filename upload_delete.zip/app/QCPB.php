<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QCPB extends Model
{
    protected $table = 'qcpb_tabels';
    protected $primaryKey = 'id_qcpb';
    public $timestamps = false;
}
