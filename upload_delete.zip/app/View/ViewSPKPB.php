<?php

namespace App\View;

use Illuminate\Database\Eloquent\Model;

class ViewSPKPB extends Model
{
  protected $table = 'view_spkpb';
  protected $primaryKey = 'id_spkpb';
  public $timestamps = false;
}
