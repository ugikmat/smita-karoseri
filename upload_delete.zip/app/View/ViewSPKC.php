<?php

namespace App\View;

use Illuminate\Database\Eloquent\Model;

class ViewSPKC extends Model
{
    protected $table = 'view_spkc';
}
