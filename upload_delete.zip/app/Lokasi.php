<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lokasi extends Model
{
    protected $table = 'master_lokasis';
    protected $primaryKey = 'id_lokasi';
}
