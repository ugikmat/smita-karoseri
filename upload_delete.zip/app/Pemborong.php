<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pemborong extends Model
{
  protected $table = 'master_pemborongs';
  protected $primaryKey = 'id_pb';
}
