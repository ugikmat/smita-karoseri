<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class produk extends Model
{
    public $timestamps=false;
    protected $primaryKey = 'id_produk';
    protected $table = 'master_produks';
}
