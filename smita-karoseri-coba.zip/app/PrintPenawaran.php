<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrintPenawaran extends Model
{
    protected $table = 'penawarans';
    public $timestamps = false;
}
