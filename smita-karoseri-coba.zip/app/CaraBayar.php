<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CaraBayar extends Model
{
    protected $table = 'cara_bayars';
    public $timestamps = false;
}
