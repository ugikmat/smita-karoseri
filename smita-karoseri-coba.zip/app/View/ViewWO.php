<?php

namespace App\View;

use Illuminate\Database\Eloquent\Model;

class ViewWO extends Model
{
    protected $table = 'view_wo';
}
