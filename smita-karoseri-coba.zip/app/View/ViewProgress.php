<?php

namespace App\View;

use Illuminate\Database\Eloquent\Model;

class ViewProgress extends Model
{
    protected $table = 'view_progress_unit';
}
