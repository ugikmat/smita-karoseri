<?php

namespace App\View;

use Illuminate\Database\Eloquent\Model;

class ViewPermintaan extends Model
{
  protected $table = 'view_permintaan';
  protected $primaryKey = 'id_spkc';
}
