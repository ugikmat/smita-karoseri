<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gudang extends Model
{
    protected $table = 'master_gudangs';
    protected $primaryKey = 'id_gudang';
}
//class GudangView extends Model
//{
  //  protected $table = 'view_gudang';
//}
