<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    public $timestamps =false;
    protected $primaryKey = 'id_supplier';
    protected $table = 'master_suppliers';
}
