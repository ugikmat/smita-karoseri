<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SPKPB extends Model
{
    protected $table = 'spkpbs';
    protected $primaryKey = 'id_spkpb';
    public $timestamps = false;

}
