<?php $__env->startSection('title', 'Persediaan Dompul'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Mutasi Dompul</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/datepicker/css/bootstrap-datepicker.min.css')); ?>">
<style>
  th{
    text-align: center;
    margin: auto;
    padding: 10%;
  }
  td{
    text-align: center;
    margin: auto;
    padding: 10%;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid form-inline">
  <form class="invoice-dompul repeater" action="" method="post">
  <?php echo csrf_field(); ?>
  <div class="row">
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
        Tanggal Awal :
        <?php if(Session::has('tgl_stok_dompul')): ?>
          <input class="datepicker form-control" data-date-format="dd-mm-yyyy" id="tgl_awal" name="tgl_awal" value="<?php echo e(session('tgl_stok_dompul')); ?>">
        <?php else: ?>
          <input class="datepicker form-control" data-date-format="dd-mm-yyyy" id="tgl_awal" name="tgl_awal" value="<?php echo e(Carbon\Carbon::now()->format('d-m-Y')); ?>">
        <?php endif; ?>
    </div>

    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
        Tanggal Akhir :
        <?php if(Session::has('tgl_stok_dompul')): ?>
          <input class="datepicker form-control" data-date-format="dd-mm-yyyy" id="tgl_akhir" name="tgl_akhir" value="<?php echo e(session('tgl_stok_dompul')); ?>">
        <?php else: ?>
          <input class="datepicker form-control" data-date-format="dd-mm-yyyy" id="tgl_akhir" name="tgl_akhir" value="<?php echo e(Carbon\Carbon::now()->format('d-m-Y')); ?>">
        <?php endif; ?>
    </div>

    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <button type="button" id="save" class="btn btn-success" ><i class="fa fa-caret-square-o-right"></i>Tampilkan Mutasi Dompul</button>
    </div>
  </div>
</div>
<br><br>

<table id="mutasi-dompul-semua-cvs-table" class="table responsive" width="100%">
    <thead>
      <tr>
        <th>Nama Produk</th>
        <?php if(isset($saless)): ?>
          <?php $__currentLoopData = $saless; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($sales->nm_sales); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </tr>
    </thead>
</table>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('/datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- <script type="text/javascript">
  $('.chosen-select').chosen();
  <?php if(Session::has('sales_stok_dompul')): ?>
    $("#sales").val("<?php echo e(session('sales_stok_dompul')); ?>");
  <?php endif; ?>
  $('#sales').trigger("chosen:updated");
</script>
<script>
  $('.datepicker').datepicker({
  });
</script>
<script>
    $(function () {
        $tgl_akhir = $('#tgl_akhir').val();
        $tgl_awal = $('#tgl_awal').val();
        $sales = $('#sales').val();
        var t = $('#mutasi-dompul-semua-cvs-table').DataTable({
            serverSide: true,
            processing: true,
            stateSave: true,
            scrollX: true,
            lengthMenu: [ [10, 25, 50, 100, -1], [10, 25, 50, 100, "All"] ],
            ajax: `/operasional/smita/stok-dompul/all/data/${$tgl_awal}/${$tgl_akhir}`,
            columns: [
              // {data: 'indeks'},
              {data: 'nama_produk'},
              <?php if(isset($saless)): ?>
                <?php $__currentLoopData = $saless; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  {data: "<?php echo e($sales->nm_sales); ?>"},
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            ],
            dom: 'lBrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        });
        $('#save').on('click',function(event) {
          $tgl_akhir = $('#tgl_akhir').val();
        $tgl_awal = $('#tgl_awal').val();
          $sales = $('#sales').val();
          t.ajax.url(`/operasional/smita/stok-dompul/all/data/${$tgl_awal}/${$tgl_akhir}`).load();
        });
    });
</script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>