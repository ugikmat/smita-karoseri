 <?php $__env->startSection('title', 'User'); ?> <?php $__env->startSection('content_header'); ?>
<h1>Change Password</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form method="post" data-parsley-validate class="form-horizontal form-label-left" action="/user/reset" id="editForm">
    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
  <div class="container-fluid form-inline">
  <div class="row">
    <div class="col-xs-6 col-sm-6">
      Password lama&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;:&emsp;
      <input type="password" id="oldpassword" name="oldpassword" class="form-control" value="" autocomplete="off" required>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-xs-6 col-sm-6">
      Password baru&emsp;&emsp;&emsp;&emsp;:&emsp;
      <input type="password" id="password" name="password" class="form-control" value="" autocomplete="off" required>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-xs-6 col-sm-6">
      Konfirmasi Password baru&emsp;&nbsp;:&emsp;
      <input type="password" id="konfirmasi" name="konfirmasi" class="form-control" value="" autocomplete="off" required>
    </div>
  </div>
  <br>
  </div>

    <div class="ln_solid"></div>
    <div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
            <button type="submit" class="btn btn-success">Simpan</button>
        </div>
    </div>
</form>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>