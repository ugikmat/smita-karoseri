<?php $__env->startSection('title', 'Dompul Head Server'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Laporan Transaksi Penjualan Dompul Server</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
  th{
    text-align: center;
  }
  td{
    text-align: center;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<table id="dompul-head-server-table" class="table responsive" width="100%">
    <thead>
      <tr>
        <th rowspan="2">No.</th>
        <th rowspan="2">Nama BO</th>
        <th colspan="3">Qty Penjualan</th>
      </tr>
      <tr>
        <th>5K</th>
        <th>10K</th>
        <th>Rupiah</th>
      </tr>
    </thead>
    <tfoot>
      <tr>
        <td></td>
        <td><b>Grand Total</b></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
    </tfoot>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(function () {
        $('#dompul-head-server-table').DataTable({
            serverSide: true,
            // processing: true,
            ajax: '/dompul-head-server-data',
            columns: [
                {data: ''},
                {data: ''},
                {data: 'action', orderable: false, searchable: false}
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>