<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sales extends Model
{
    protected $table = 'master_saless';
    protected $primaryKey = 'id_sales';
}
