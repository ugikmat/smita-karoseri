<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BAP extends Model
{
    protected $table = 'view_bap';
}
