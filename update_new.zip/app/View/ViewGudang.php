<?php

namespace App\View;

use Illuminate\Database\Eloquent\Model;

class ViewGudang extends Model
{
    protected $table = 'view_gudang';
}
