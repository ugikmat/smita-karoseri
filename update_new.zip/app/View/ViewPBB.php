<?php

namespace App\View;

use Illuminate\Database\Eloquent\Model;

class ViewPBB extends Model
{
  protected $table = 'view_pbb';
  protected $primaryKey = 'id_pbb';
}
