<?php

namespace App\View;

use Illuminate\Database\Eloquent\Model;

class ViewProduksi extends Model
{
    protected $table = 'view_produksi';
}
