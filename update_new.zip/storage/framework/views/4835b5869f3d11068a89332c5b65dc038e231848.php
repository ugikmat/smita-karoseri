<?php $__env->startSection('title', 'Penjualan Dompul Head'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Penjualan Dompul Head</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/datepicker/css/bootstrap-datepicker.min.css')); ?>">
<style media="screen">
  a{
    text-decoration: none;
    color: white;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="cotainer-fluid">
  <form action="/penjualan/laporan-penjualan/dompul-head-show" method="post">
    <?php echo csrf_field(); ?>
  <div class="row">
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
        <label class="control-label" for="first-name">Pilih Tanggal :</label>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
      <input class="datepicker" data-date-format="dd-mm-yyyy" name="tgl" value="<?php echo e(session('tgl_laporan_head')); ?>" required>
      </div>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      <button class="btn btn-danger" type="reset"> <i class="fa fa-repeat"></i> Kosongkan</button>
      <button type="submit" class="btn btn-primary" name="action" value="user"><i class="glyphicon glyphicon-user"></i> Tampilkan Laporan Transaksi User</button>
      <button type="submit" class="btn btn-success" name="action" value="server"><i class="fa fa-server"></i> Tampilkan Laporan Transaksi Server</button>
    </div>
  </div>
  </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('/datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<script>
  $('.datepicker').datepicker({
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>