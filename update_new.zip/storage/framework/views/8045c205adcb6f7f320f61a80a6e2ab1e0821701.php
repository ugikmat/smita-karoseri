<?php $__env->startSection('title', 'Persediaan SP'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Mutasi SP</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/datepicker/css/bootstrap-datepicker.min.css')); ?>">
<style>
  th{
    text-align: center;
    margin: auto;
    padding: 10%;
  }
  td{
    text-align: center;
    margin: auto;
    padding: 10%;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid form-inline">
  <form class="invoice-sp repeater" action="/operasional/smita/persediaan/sp/mutasi-sp-semua-cvs/show" method="post">
  <?php echo csrf_field(); ?>
  <div class="row">
    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <strong>Tanggal Awal :</strong>
        <?php if(Session::has('tgl_awal_stok_sp')): ?>
          <input class="datepicker form-control" data-date-format="dd-mm-yyyy" id="tgl_awal" name="tgl_awal" value="<?php echo e(session('tgl_awal_stok_sp')); ?>">
        <?php else: ?>
          <input class="datepicker form-control" data-date-format="dd-mm-yyyy" id="tgl_awal" name="tgl_awal" value="<?php echo e(Carbon\Carbon::now()->format('d-m-Y')); ?>">
        <?php endif; ?>
    </div>

    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <strong>Tanggal Akhir :</strong>
        <?php if(Session::has('tgl_akhir_stok_sp')): ?>
          <input class="datepicker form-control" data-date-format="dd-mm-yyyy" id="tgl_akhir" name="tgl_akhir" value="<?php echo e(session('tgl_akhir_stok_sp')); ?>">
        <?php else: ?>
          <input class="datepicker form-control" data-date-format="dd-mm-yyyy" id="tgl_akhir" name="tgl_akhir" value="<?php echo e(Carbon\Carbon::now()->format('d-m-Y')); ?>">
        <?php endif; ?>
    </div>

    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
      <strong>Lokasi :</strong> &nbsp;
      <select name="lokasi" required="required" class="form-control chosen-select" id="lokasi">
        <option value="" disabled selected>Pilih Lokasi</option>
        <?php if(isset($lokasis)): ?>
          <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($lokasi->id_lokasi); ?>" id="<?php echo e($lokasi->nm_lokasi); ?>"><?php echo e($lokasi->nm_lokasi); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </select>
    </div>

    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
      <button type="submit" class="btn btn-success" ><i class="fa fa-caret-square-o-right"></i>Tampilkan Mutasi SP</button>
    </div>
  </div>
  </form>
</div>
<br><br>

<table id="mutasi-sp-semua-cvs-table" class="table responsive" width="100%">
    <thead>
      <tr>
        <th>Nama Produk</th>
        <?php if(isset($saless)): ?>
          <?php $__currentLoopData = $saless; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($sales->nm_sales); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </tr>
    </thead>
</table>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('/datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<script type="text/javascript">
  $('.chosen-select').chosen();
  <?php if(Session::has('mutasi_lokasi')): ?>
    $("#lokasi").val("<?php echo e(session('mutasi_lokasi')); ?>");
    $('#lokasi').trigger("chosen:updated");
  <?php endif; ?>
</script>
<script>
  $('.datepicker').datepicker({
  });
</script>
<script>
    $(function () {
        $tgl_akhir = $('#tgl_akhir').val();
        $tgl_awal = $('#tgl_awal').val();
        $sales = $('#sales').val();
        var t = $('#mutasi-sp-semua-cvs-table').DataTable({
            serverSide: true,
            processing: true,
            stateSave: true,
            scrollX: true,
            lengthMenu: [ [10, 25, 50, 100, -1], [10, 25, 50, 100, "All"] ],
            ajax: `/operasional/smita/stok-sp/all/data/${$tgl_awal}/${$tgl_akhir}`,
            columns: [
              // {data: 'indeks'},
              {data: 'nama_produk'},
              <?php if(isset($saless)): ?>
                <?php $__currentLoopData = $saless; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  {data: "<?php echo e($sales->nm_sales); ?>"},
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            ],
            dom: 'lBrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        });
        $('#save').on('click',function(event) {
          $tgl_akhir = $('#tgl_akhir').val();
        $tgl_awal = $('#tgl_awal').val();
          $sales = $('#sales').val();
          t.ajax.url(`/operasional/smita/stok-sp/all/data/${$tgl_awal}/${$tgl_akhir}`).load();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>