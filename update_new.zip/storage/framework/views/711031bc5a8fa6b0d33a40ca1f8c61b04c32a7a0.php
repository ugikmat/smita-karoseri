<?php $__env->startSection('title', 'Laporan SP'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detail Piutang SP</h1>

<?php $__env->stopSection(); ?>
<style>
  td{
    white-space: nowrap;
  }
</style>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="cotainer-fluid">
  <div class="row">
    <input type="hidden" id="tgl" value="<?php echo e(session('tgl_laporan_sp')); ?>" readonly>
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        Tanggal Awal
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        : <?php echo e(session('tgl_laporan_sp')); ?>

      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        Tanggal Akhir
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        : <?php echo e(session('tgl_laporan_sp')); ?>

      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        Nama Kasir
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        : Joni
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        Nama Logistic
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        : gege
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        Nama PIC
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        : jhon
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        ID Canvaser
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <input type="hidden" id="id_sales" value="<?php echo e($sales->id_sales); ?>" readonly>
        :<strong><?php echo e($sales->id_sales); ?></strong>
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        Nama Canvaser
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        : <strong><?php echo e($sales->nm_sales); ?></strong>
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">

    </div>
  </div>
</div>
<br><br>

<table id="lp-sp-2-table" class="table responsive table-bordered" width="100%">
    <thead>
    <tr>
        <th>No.</th>
        <th>Nama RO</th>
        <th>Total Tagihan</th>
        <th>Piutang</th>
    </tr>
    </thead>
    <tfoot>
      <tr>
        <td></td>
        <td><b>Grand Total</b></td>
        <td><input type="text" name="tagihan" id="tagihan" class="form-control" value="<?php echo e(number_format($total_penjualan,0,"",".")); ?>" readonly></td>
        <td><input type="text" name="piutang" id="piutang" class="form-control" value="<?php echo e(number_format($total_piutang,0,"",".")); ?>" readonly> </td>
      </tr>
    </tfoot>
</table>
<br>
  <a href="<?php echo e(URL::previous()); ?>" class="pull-left"><button type="button" class="btn btn-danger"><span class="glyphicon glyphicon-chevron-left"></span> Kembali</button></a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
  var id = $('#id_sales').val();
  var tgl = $('#tgl').val();
  console.log('/laporan-penjualan/sp/piutang/'+id);
  var t = $('#lp-sp-2-table').DataTable({
            serverSide: true,
            processing: true,
            ajax: '/laporan-penjualan/sp/piutang/'+id+'/'+tgl,
            "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
                } ],
            "order": [[ 1, 'asc' ]],
            columns: [
                {data: 'index'},
                {data: 'nm_cust'},
                {data: 'total_penjualan'},
                {data: 'piutang'}
            ],
            dom: 'lBrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        });
        t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
          } );
        } ).draw();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>