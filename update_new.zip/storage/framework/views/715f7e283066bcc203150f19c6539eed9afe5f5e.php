<?php $__env->startSection('title', 'Pengambilan SP'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Review Pengambilan SP</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
td{
  background-color: white;
}
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- sama kayak invoice-sp-2 -->
<form class="invoice-ambil-sp" action="/operasional/smita/ambil-sp/store" method="post">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="lokasi" value="<?php echo e($lokasi); ?>">
<input type="hidden" name="id" id="id" value="<?php echo e($pengambilanSp->id_pengambilan_sp); ?>">
<div class="container-fluid">
  <div class="row">
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
          Nama Canvaser :
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-8">
        <input type="text" name="canvasser" id="canvasser" value="<?php echo e($sales->nm_sales); ?>" disabled>
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
          No HP Canvaser :
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-8">
        <?php if(isset($sales)): ?>
           <?php echo e($sales->no_hp); ?>

        <?php endif; ?>
      </div>
    </div>
    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        Tanggal Pengambilan :
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
            <input class="datepicker" data-date-format="dd-mm-yyyy" id="tgl" value="<?php echo e(Carbon\Carbon::parse($pengambilanSp->tanggal_pengambilan_sp)->format('d/m/Y')); ?>" readonly>
      </div>
    </div>
  </div>
</div>

<table id="invoice-ambil-sp-table" class="table responsive"  width="100%">
    <thead>
    <tr>
      <th>Nama Barang</th>
      <th>Tipe Harga</th>
      
      <th>Jumlah</th>
    </tr>
    </thead>
    
</table>
<br>
<div class="container form-inline">
  <div class="row">
    <a href="<?php echo e(URL::previous()); ?>"><button type="button" class="btn btn-danger"><span class="glyphicon glyphicon-chevron-left"></span> Kembali</button></a>
    <!-- ngelink ke awal, invoice ambil -->
    <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-ok"></span> Simpan</button>
  </div>
</div>

</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
function goBack() {
    window.history.back()
}
</script>
<script>
  $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
    $(function () {
        var id = $('#id').val();
        var t = $('#invoice-ambil-sp-table').DataTable({
                  serverSide: true,
                  processing: true,
                  stateSave: true,
                  searching:  false,
                  ajax: `/operasional/smita/ambil-sp/data/${id}`,
                  columns: [
                      {data: 'nama_produk'},
                      {data: 'tipe_harga'},
                      {data: 'jumlah'},
                  ]
              });
        console.log('<?php echo e(session('total_harga_sp')); ?>');
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>